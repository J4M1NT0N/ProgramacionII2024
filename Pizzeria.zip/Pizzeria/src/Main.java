public class Main {
    public static void main(String[] args) {
        // Crear ingredientes
        Masa masa = new Masa("Fina", 1);
        Salsa salsa = new Salsa("Marinara", 1);
        Queso queso = new Queso("Mozzarella", 1);

        // Crear pizzas
        Pizza pizzaNY = new PizzaNuevaYork("Pizza Nueva York", "Grande", 15.99, masa, salsa, queso, "Corte en triángulo");
        Pizza pizzaChicago = new PizzaChicago("Pizza Chicago", "Mediana", 18.99, masa, salsa, queso, "Masa gruesa");

        // Crear empleados
        Empleado empleado1 = new Empleado("Juan", "Cocinero", 25000);
        Empleado empleado2 = new Empleado("Ana", "Cajero", 20000);

        // Crear equipos
        Equipo horno = new Equipo("Horno", "Operativo");
        Equipo batidora = new Equipo("Batidora", "En reparación");

        // Crear sucursal
        Sucursal sucursal = new Sucursal("Sucursal Centro", "Av. Principal 123");

        // Agregar empleados, ingredientes y equipos a la sucursal
        sucursal.agregarEmpleado(empleado1);
        sucursal.agregarEmpleado(empleado2);

        sucursal.agregarIngrediente(masa);
        sucursal.agregarIngrediente(salsa);
        sucursal.agregarIngrediente(queso);

        sucursal.agregarEquipo(horno);
        sucursal.agregarEquipo(batidora);

        // Agregar especialidades a la sucursal
        sucursal.agregarEspecialidad(pizzaNY);
        sucursal.agregarEspecialidad(pizzaChicago);

        // Mostrar la preparación de las pizzas
        pizzaNY.preparar();
        pizzaNY.hornear();
        pizzaNY.cortar();
        pizzaNY.empacar();
        pizzaNY.especial();

        pizzaChicago.preparar();
        pizzaChicago.hornear();
        pizzaChicago.cortar();
        pizzaChicago.empacar();
        pizzaChicago.especial();
    }
}
