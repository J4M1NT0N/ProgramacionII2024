package ingrediente;

public interface Ingrediente {
    String obtenerNombre();
    int obtenerCantidad();
}

